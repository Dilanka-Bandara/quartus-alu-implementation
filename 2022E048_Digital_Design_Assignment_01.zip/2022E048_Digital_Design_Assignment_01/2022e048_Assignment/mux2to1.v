module mux2to1 (
    input wire A,     // Input A
    input wire B,     // Input B
    input wire S,     // Select Signal
    output wire Y     // Output Y
);
    assign Y = (S) ? B : A;  // Multiplexer Logic
endmodule
