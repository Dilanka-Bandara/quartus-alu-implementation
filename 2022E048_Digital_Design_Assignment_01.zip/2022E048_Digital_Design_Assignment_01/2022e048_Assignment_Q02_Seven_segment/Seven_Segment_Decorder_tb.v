`timescale 1ns/1ps
module tb_seven_segment_decoder();
    reg [3:0] A;
    wire [6:0] segments;

    // Instantiate the 7-Segment Decoder
    seven_segment_decoder uut (
        .A(A),
        .segments(segments)
    );

    initial begin
        // Loop through all hex values 0-F
        for (A = 0; A < 16; A = A + 1) begin
            #10;
        end

        $stop; // Stop the simulation
    end
endmodule
