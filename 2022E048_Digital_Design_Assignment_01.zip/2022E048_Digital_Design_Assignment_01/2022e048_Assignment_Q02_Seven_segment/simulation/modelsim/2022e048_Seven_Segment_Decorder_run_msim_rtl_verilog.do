transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vlog -vlog01compat -work work +incdir+C:/Users/DILANKA/Desktop/2022E048_Digital_Design_Assignment/2022e048_Assignment_Q02_Seven_segment {C:/Users/DILANKA/Desktop/2022E048_Digital_Design_Assignment/2022e048_Assignment_Q02_Seven_segment/seven_segment_decoder.v}

vlog -vlog01compat -work work +incdir+C:/Users/DILANKA/Desktop/2022E048_Digital_Design_Assignment/2022e048_Assignment_Q02_Seven_segment {C:/Users/DILANKA/Desktop/2022E048_Digital_Design_Assignment/2022e048_Assignment_Q02_Seven_segment/Seven_Segment_Decorder_tb.v}

vsim -t 1ps -L altera_ver -L lpm_ver -L sgate_ver -L altera_mf_ver -L altera_lnsim_ver -L cyclone10lp_ver -L rtl_work -L work -voptargs="+acc"  seven_segment_decoder_tbb

add wave *
view structure
view signals
run -all
