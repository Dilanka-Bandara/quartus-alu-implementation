module alu8bit (
    input wire [7:0] A,   // 8-bit Input A
    input wire [7:0] B,   // 8-bit Input B
    input wire [2:0] Op,  // 3-bit Operation Code
    output reg [7:0] Result // 8-bit Output
);
    always @(*) begin
        case (Op)
            3'b000: Result = A + B;      // ADD
            3'b001: Result = A - B;      // SUBTRACT
            3'b010: Result = A & B;      // AND
            3'b011: Result = A | B;      // OR
            3'b100: Result = A ^ B;      // XOR
            3'b101: Result = ~(A & B);   // NAND
            3'b110: Result = ~(A | B);   // NOR
            3'b111: Result = ~A;         // NOT (ignores B)
            default: Result = 8'b00000000; // Default: Zero Output
        endcase
    end
endmodule
