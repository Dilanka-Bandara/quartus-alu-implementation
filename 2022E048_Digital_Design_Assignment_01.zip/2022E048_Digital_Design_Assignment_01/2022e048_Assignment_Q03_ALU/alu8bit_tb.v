`timescale 1ns/1ps
module tb_alu8bit();
    reg [7:0] A, B;
    reg [2:0] Op;
    wire [7:0] Result;

    // Instantiate the ALU
    alu8bit uut (
        .A(A),
        .B(B),
        .Op(Op),
        .Result(Result)
    );

    initial begin
        A = 8'b00001111; B = 8'b00000011;

        Op = 3'b000; #10;  // ADD
        Op = 3'b001; #10;  // SUBTRACT
        Op = 3'b010; #10;  // AND
        Op = 3'b011; #10;  // OR
        Op = 3'b100; #10;  // XOR
        Op = 3'b101; #10;  // NAND
        Op = 3'b110; #10;  // NOR
        Op = 3'b111; #10;  // NOT (ignores B)

        $stop; // Stop the simulation
    end
endmodule
