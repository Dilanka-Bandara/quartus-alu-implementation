transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vlog -vlog01compat -work work +incdir+C:/Users/DILANKA/Desktop/2022E048_Digital_Design_Assignment/2022e048_Assignment_Q03_ALU {C:/Users/DILANKA/Desktop/2022E048_Digital_Design_Assignment/2022e048_Assignment_Q03_ALU/alu8bit.v}

vlog -vlog01compat -work work +incdir+C:/Users/DILANKA/Desktop/2022E048_Digital_Design_Assignment/2022e048_Assignment_Q03_ALU {C:/Users/DILANKA/Desktop/2022E048_Digital_Design_Assignment/2022e048_Assignment_Q03_ALU/alu8bit_tb.v}

vsim -t 1ps -L altera_ver -L lpm_ver -L sgate_ver -L altera_mf_ver -L altera_lnsim_ver -L cyclone10lp_ver -L rtl_work -L work -voptargs="+acc"  alu8bit_Tbb

add wave *
view structure
view signals
run 100 ns
