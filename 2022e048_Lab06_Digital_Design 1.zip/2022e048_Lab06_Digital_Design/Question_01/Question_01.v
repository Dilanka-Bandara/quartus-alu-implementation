`timescale 1 ps/1 ps
module Question_01(x1,x2,Y1,Y2);

input x1,x2;
output Y1,Y2;
wire w1,w2,w3,w4,w5;

not #10 G1 (w1,x1);
not #10 G2 (w5,x2);
nand #10 G3 (w2,w1,x2);
nand #10 G4 (w3,x2,Y1);
nand #10 G5 (Y1,w2,w3);
nand #10 G6 (w4,x1,Y2);
nand #10 G7 (Y2,w4,w5);

endmodule

