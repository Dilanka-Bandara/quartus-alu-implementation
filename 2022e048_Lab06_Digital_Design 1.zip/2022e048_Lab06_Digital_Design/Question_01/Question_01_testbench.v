`timescale 1 ps/1 ps

module Question_01_testbench;

  reg x1,x2;
  wire Y1,Y2;
  
Question_01 u1(

		.x1(x1),
		.x2(x2),
		.Y1(Y1),
	   .Y2(Y2)
		);
 
  
initial
	begin
			x1=0; x2=0;
	#10	x1=1; x2=0;
	#10	x1=1; x2=1;
	#10	x1=0; x2=1;
	#10	x1=1; x2=1;
	#10	x1=1; x2=0;
	#10	x1=0; x2=0;
	#20	
	$stop;
	$finish;
	end
	   
endmodule