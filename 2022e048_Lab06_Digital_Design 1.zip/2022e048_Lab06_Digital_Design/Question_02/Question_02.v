module srlatch (	input s,r,
					output reg y, ybar);
					
	initial begin 
		y = 1'b0;
		ybar = 1'b1;
	end
	
	always @ (s or r)//check only at s or r to reduce compunational strain
	begin
		if (s&(~r))
			y = 1'b0;
		else if (r&(~s))
         y = 1'b1;
	end
	
	always @ (s or r)
	begin
		if (s&(~r))
			ybar = 1'b1;
		else if (r&(~s))
         ybar = 1'b0;
	end
	
endmodule

module Question_02 (	input t,c,
					output q);
	
	wire q_in,qbar_in;
	
	wire s, r, qbar;
	
	assign #10 s=~(t & c & qbar_in);
	assign #10 r=~(t & c & q_in);
		
	srlatch sr1(.s(s),.r(r), .y(q),.ybar(qbar));
	
	assign #10 q_in    =  q;
	assign #10 qbar_in =  qbar;
	
	
endmodule 