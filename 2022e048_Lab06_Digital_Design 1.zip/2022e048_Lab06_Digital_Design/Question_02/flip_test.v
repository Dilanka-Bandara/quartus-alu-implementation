module flip_test();
	
	reg t_in, c_in;
	wire q_out;
	
	flip flip_dut(.t(t_in), .c(c_in), .q(q_out));
	
	// t a shifted square wave of period 80000 (shisted by pi/8)
	always
	begin
		t_in = 1'b1;
		t_in = #10000 1'b0;
		t_in = #40000 1'b1;
		#30000;
	end 

	// c a square pulse of period 40000
	always
	begin
		repeat(4)
		begin
			c_in = 1'b0;
			c_in = #20000 1'b1;
			#20000;
		end
		repeat(4)
		begin
			c_in = 1'b1;
			c_in = #20000 1'b0;
			#20000;
		end
	end
	
endmodule
