`timescale 1ps/1ps
module srlatch (	input s,r,
					output reg y, ybar);				
	initial begin 
		y = 1'b0;
		ybar = 1'b1;
	end
	always @ (s or r)//see s or r to reduce compunational strain
	begin
		if (s&(~r))
			y = 1'b0;
		else if (r&(~s))
         y = 1'b1;
	end	
	always @ (s or r)
	begin
		if (s&(~r))
			ybar = 1'b1;
		else if (r&(~s))
         ybar = 1'b0;
	end	
endmodule

module Question_03 (t,c,q);
input t,c;
output q;

wire tbar,cbar,r1,s1,r2,s2,A,B,C,D,y1,y2,y1bar,y2bar;
assign #10 tbar = ~t;
assign #10 cbar = ~c;
assign #10 A = ~(t & c & y2bar);
assign #10 B= ~(tbar & cbar & y2bar);
assign #10 C = ~(tbar & cbar & y2);
assign #10 D = ~(t & c & y2);
assign #10 r1= A & C;
assign #10 s1= B & D;
srlatch sr1(.s(s1),.r(r1), .y(y1),.ybar(y1bar));
assign #10 s2 = ~(y1bar & cbar & t);
assign #10 r2= ~(y1 & cbar & t);
srlatch sr2(.s(s2),.r(r2), .y(y2),.ybar(y2bar));
assign q = y2;

endmodule 


