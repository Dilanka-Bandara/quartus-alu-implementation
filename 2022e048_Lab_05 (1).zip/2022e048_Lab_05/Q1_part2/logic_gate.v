module logic_gate (

    input X,   // Input X
    input Y,   // Input Y
    input Z,   // Input Z
    output Output // Output of the circuit
	 
);
    wire and1_out; // first AND gate
    wire and2_out; // second AND gate
    wire not_out;  // NOT gate

    not u1 (not_out, Y);

    and u2 (and1_out, X, Y);

    and u3 (and2_out, not_out, Z);

    or u4 (Output, and1_out, and2_out);
	 
endmodule