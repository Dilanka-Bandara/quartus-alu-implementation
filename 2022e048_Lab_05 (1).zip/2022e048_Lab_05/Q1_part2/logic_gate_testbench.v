`timescale 1ns / 1ps
module tb_logic_gate;
    // Inputs
    reg X;
    reg Y;
    reg Z;

    wire Output;

    logic_gate dut (
        .X(X),
        .Y(Y),
        .Z(Z),
        .Output(Output)
    );

    // Generate square wave for 
	 // X (10 ns on-time)
    initial begin
        X = 0;
        forever #10 X = ~X; 
    end
	 // Y (20 ns on-time)
    initial begin
        Y = 0;
        forever #20 Y = ~Y; 
    end
    // Z (40 ns on-time)
    initial begin
        Z = 0;
        forever #40 Z = ~Z;
    end
    initial begin
        #200;
        $stop;  // Stop simulation after 200 ns
    end
	 
endmodule