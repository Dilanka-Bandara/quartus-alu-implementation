module JKff_tb();

    reg J_in, K_in, CLK;
    wire Q_out;
    
    reg [2:0] testvectors [7:0];
    integer i = 0;
    
    initial begin
        // Initialize test vectors for J_in and K_in inputs
        testvectors[0] <= 2'b10;  // Set
        testvectors[1] <= 2'b00;  // Hold
        testvectors[2] <= 2'b01;  // Reset
        testvectors[3] <= 2'b00;  // Hold
        testvectors[4] <= 2'b10;  // Set
        testvectors[5] <= 2'b11;  // Toggle
        testvectors[6] <= 2'b01;  // Reset
        testvectors[7] <= 2'b11;  // Toggle
    end
    
    // Instantiate the JK flip-flop
    JKflip JKflip_dut(
        .J_in(J_in),
        .K_in(K_in),
        .CLK(CLK),
        .Q_out(Q_out)
    );
    
    // Clock generation
    always begin
        CLK = 1'b0;
        #5;
        CLK = 1'b1;
        #5;
    end

    // Apply test vectors to the inputs
    always @(posedge CLK) begin
        if (i == 8) begin
            i = 0;  // Reset the index after 8 test vectors
        end
        {J_in, K_in} = testvectors[i];  // Apply current test vector
        i = i + 1;
    end

endmodule
