module JKflip(
    input J_in,
    input K_in,
    input CLK,
    output reg Q_out
);
    
    always @(posedge CLK) begin
        case ({J_in, K_in})
            2'b00: Q_out <= Q_out;      // Hold
            2'b01: Q_out <= 0;         // Reset
            2'b10: Q_out <= 1;         // Set
            2'b11: Q_out <= ~Q_out;    // Toggle
            default: Q_out <= Q_out;   // Default state
        endcase
    end

endmodule
