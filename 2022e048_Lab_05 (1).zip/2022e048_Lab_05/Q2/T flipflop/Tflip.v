module Tflip(
    input T_in,
    input CLK,
    input rst_in,
    output reg Q_out
);

    always @(posedge CLK or posedge rst_in) begin
        if (rst_in)
            Q_out <= 0;  // Reset
        else if (T_in)
            Q_out <= ~Q_out;  // Toggle
        else
            Q_out <= Q_out;  // Hold
    end

endmodule
