module Tfliptb();

    reg T_in, rst_in, CLK;
    wire Q_out;
    
    reg [2:0] testvectors [4:0];
    integer i = 0;
    
    initial begin
        // Initialize test vectors for T_in and rst_in inputs
        testvectors[0] <= 2'b10;  // Reset
        testvectors[1] <= 2'b00;  // Hold
        testvectors[2] <= 2'b01;  // Toggle
        testvectors[3] <= 2'b00;  // Hold
        testvectors[4] <= 2'b01;  // Toggle
    end
    
    // Instantiate the T flip-flop
    Tflip Tflip_dut(
        .T_in(T_in),
        .CLK(CLK),
        .rst_in(rst_in),
        .Q_out(Q_out)
    );
    
    // Clock generation
    always begin
        CLK = 1'b0;
        #5;
        CLK = 1'b1;
        #5;
    end

    // Apply test vectors to the inputs
    always @(posedge CLK) begin
        if (i == 5) begin
            i = 0;  // Reset the index after 5 test vectors
        end
        {rst_in, T_in} = testvectors[i];  // Apply current test vector
        i = i + 1;
    end

endmodule
