transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vlog -vlog01compat -work work +incdir+C:/FPGA/Q2/t {C:/FPGA/Q2/t/Tflip.v}

vlog -vlog01compat -work work +incdir+C:/FPGA/Q2/t {C:/FPGA/Q2/t/Tfliptb.v}

vsim -t 1ps -L altera_ver -L lpm_ver -L sgate_ver -L altera_mf_ver -L altera_lnsim_ver -L cyclone10lp_ver -L rtl_work -L work -voptargs="+acc"  testBench

add wave *
view structure
view signals
run 10 ns
